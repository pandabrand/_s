This is just here so you know where all the assets will live the should be a grunt task that will create the necessary directories.
