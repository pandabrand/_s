<?php
/**
 * Custom functions that act made explicitly for this theme.
 *
 *
 * @package _pandapress
 */

 if ( ! function_exists( 'mtac_underscore_fonts_url' ) ) :
 /**
  * Register Google fonts for Twenty Sixteen.
  *
  * Create your own twentysixteen_fonts_url() function to override in a child theme.
  *
  * @since Twenty Sixteen 1.0
  *
  * @return string Google fonts URL for the theme.
  */
 function mtac_underscore_fonts_url() {
 	$fonts_url = '';
 	$fonts     = array();
 	$subsets   = 'latin,latin-ext';
 	/* translators: If there are characters in your language that are not supported by Merriweather, translate this to 'off'. Do not translate into your own language. */
 	if ( 'off' !== _x( 'on', 'Work Sans font: on or off', 'mtac_underscore' ) ) {
 		$fonts[] = 'Work Sans:400,500';
 	}
 	/* translators: If there are characters in your language that are not supported by Montserrat, translate this to 'off'. Do not translate into your own language. */
 	if ( 'off' !== _x( 'on', 'Open Sans font: on or off', 'mtac_underscore' ) ) {
 		$fonts[] = 'Open Sans';
 	}
 	if ( $fonts ) {
 		$fonts_url = add_query_arg( array(
 			'family' => urlencode( implode( '|', $fonts ) ),
 			'subset' => urlencode( $subsets ),
 		), 'https://fonts.googleapis.com/css' );
 	}
 	return $fonts_url;
 }
 endif;


 /**
  * Enqueue scripts and styles.
  */
 function mtac_scripts() {
   wp_enqueue_style( 'mtac_underscore-fonts', mtac_underscore_fonts_url(), array(), null );
   wp_enqueue_style( 'slick_slider_css', '//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.css', array(), null);
   wp_enqueue_script( 'fontawesome', 'https://use.fontawesome.com/e66e12446b.js', array(), '20160927', false );
   wp_enqueue_script('slick_slider', '//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js', array('jquery'), '20160930', true);

 // 	wp_enqueue_style( '_pandapress-style', get_template_directory_uri() . '/assets/css/style.css' );
	//
 // 	wp_enqueue_script( '_pandapress-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );
	//
 }
 add_action( 'wp_enqueue_scripts', 'mtac_scripts' );

 /**
 * add a custom template
 *
 * In addition to this filter, you must create a file named my_new_template.php in a /fpw2_views/ folder in the active child or parent theme
 *
 * @param	$templates	array	slug => label pairs of templates
 */
function fpw_add_widget_template( $templates ) {
	$templates['front-feature'] = __( 'Front Feature Template', '_pandapress' );
	return $templates;
}
add_filter( 'fpw_widget_templates', 'fpw_add_widget_template' );
